"""
FISSPy module for reading fts in Class form.
"""

from __future__ import absolute_import, division
from .read_factory import *

__author__= "Juhyung Kang"
__email__ = "jhkang0301@gmail.com"

