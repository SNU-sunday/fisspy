from __future__ import absolute_import, division
import numpy as np
import matplotlib.pyplot as plt

class MLSI:
    def __init__(self):
        None
    def TLI(self):
        None